DT Food POS - Super Admin panel (Firebase project: dt-food-app)

Is ZIP mein panel PEHLE SE BANA HUA hai (admin/dist), isliye build ki zaroorat nahi.

1) Node.js install hona chahiye (https://nodejs.org, LTS).
2) ZIP unzip karein. Is folder mein (jahan firebase.json hai) CMD / Terminal kholein:

     npx firebase-tools login
     npx firebase-tools deploy

   login par wahi Gmail chunein jis se dt-food-app project bana hai.
   deploy ek saath panel + Firestore rules + indexes publish karta hai.

3) Panel: https://dt-food-app.web.app  (browser mein Ctrl+F5)
   Sign in: digitaltarget.digital@gmail.com  ->  "Become Super Admin" (sirf pehli dafa)

4) Panel mein Settings bharein: App branding, App control, Billing & invoices.

Poori checklist: docs/FIREBASE_SETUP.md
Source badalna ho to: cd admin && npm install && npm run build
