DT Food POS - Super Admin panel (Firebase project: dt-food-app)

Panel PEHLE SE BANA HUA hai (admin/dist). npm install / npm run build ki zaroorat NAHI.

1) Node.js (LTS) install ho.
2) Isi folder mein (jahan firebase.json hai) CMD kholein:

     npx firebase-tools login
     npx firebase-tools deploy

3) https://dt-food-app.web.app  (Ctrl+F5)
   digitaltarget.digital@gmail.com se sign in -> "Become Super Admin" (sirf pehli dafa)

4) Settings bharein: App branding, App control, Billing (plan prices bhi).

Guide: docs/USER_GUIDE.md  ·  Setup: docs/FIREBASE_SETUP.md
